<?php 
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.gmail.com';
$config['smtp_port'] = 587;
$config['smtp_user'] = 'ankitthakur8698@gmail.com';
$config['smtp_pass'] = 'pwvtqxmqfuexswmc';

$config['smtp_crypto'] = 'tls'; // Enable TLS encryption

$config['charset'] = 'utf-8';
$config['newline'] = "\r\n";
$config['mailtype'] = 'html'; // or html
$config['validation'] = TRUE; // bool whether to validate email or not 
?>